<?php
session_start();
//check whether user is login in
if(!isset($_SESSION['email'])) {
    //redirect the user to login page
  header("Location: index.php");
  exit();
}


require_once 'connect.php';
$bookingDetails= "SELECT * FROM booking_tbl";
$result = $connect->query($bookingDetails);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel management system</title>
    <style>
        table{
  border-collapse: collapse;
  width: 100%;
}
.booking-details{
  margin-top: 40px;
  margin-bottom: 40px;
}
th,
td{
  border: 1px solid black;
  padding: 8px;
  text-align: left;
}
    </style>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css" />
</head>
<body>
  <!-- our navigation -->
    <nav>
      <div>
            <ul class="my-links">
                <li><img src="images/Eo_circle_blue_white_letter-h(0).svg" alt=""></li>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
                <li><a href="#booking">Booking</a></li>
                <li><a href="#login" class="login-btn">Login</a></li>
                <li><a href="#bookingDetails">Detials</a></li>
            </ul>
        </div>
        
    </nav>

  <!-- login -->
    <section>
      <div class="blur-bg-overlay"></div>
      <div class="form-popup">
          <span class="close-btn"><i class="fa fa-times-circle"></i></span>
          <div class="form-box login">
              <div class="form-details">
                  <h2>Welcome Back</h2>
                  <p>Please log in using your personal information to stay connected with us.</p>
              </div>
              <div class="form-content">
                  <h2>LOGIN</h2>
                  <form action="insert.php" method="POST">
                      <div class="input-field">
                          <input type="email" name="loginEmail" required>
                          <label>Email</label>
                      </div>
                      <div class="input-field">
                          <input type="password" name="loginPassword" required>
                          <label>Password</label>
                      </div>
                      <a href="#" class="forgot-pass-link">Forgot password?</a>
                      <button type="submit">Log In</button>
                  </form>
                  <div class="bottom-link">
                      Don't have an account?
                      <a href="#" id="signup-link">Signup</a>
                  </div>
              </div>
          </div>
          <div class="form-box signup">
              <div class="form-details">
                  <h2>Create Account</h2>
                  <p>To become a part of our community, please sign up using your personal information.</p>
              </div>
              <div class="form-content">
                  <h2>SIGNUP</h2>
                  <form action="signUp.php" method="POST">
                      <div class="input-field">
                          <input type="text" name="signEmail" required>
                          <label>Enter your email</label>
                      </div>
                      <div class="input-field">
                          <input type="password" name="signPassword" required>
                          <label>Create password</label>
                      </div>
                      <div class="policy-text">
                          <input type="checkbox" id="policy">
                          <label for="policy">
                              I agree the
                              <a href="#" class="option">Terms & Conditions</a>
                          </label>
                      </div>
                      <button type="submit">Sign Up</button>
                  </form>
                  <div class="bottom-link">
                      Already have an account? 
                      <a href="#" id="login-link">Login</a>
                  </div>
              </div>
          </div>
      </div>
    </section>
    
    <!-- home section -->
    <section id="home">
        <div class="banner">
            <img src="images/Royal Cliff Beach Hotel by DBALP.jpeg" alt="">
            <div class="overlay"></div>
            <div class="texts">
                <h1>Welcome to the hostel management system</h1>
                <p>Your home away from home</p>
            </div>
        </div>
    </section>
    <div class=""></div>
      
    <!-- about section -->
    <section class="section about" id="about">
        <div class="about-content container">
          <div class="about-imageContent">
                <img src="images/UDS Design The GRIDS Hostel In Tokyo.jpeg" alt="" class="about-img">
        
                <div class="aboutImg-textBox">
                    <i class="fas fa-handshake heart-icon flex"></i> 
                    <p class="content-description">Staying at your hostel was an absolute delight! </p>
                </div>
          </div>
    
          <div class="about-details">
            <div class="about-text">
              <h4 class="content-subtitle"><i>Our hostels</i></h4>
              <h2 class="content-title">We Combine Classics <br> and Modernity</h2>
              <p class="content-description">We appreciate your trust greatly.
                Our clients choose us <br> because they know we are the best and we provide the quality.</p>
    
              <ul class="about-lists flex">
                <li class="about-list dot"><span class="dd">.</span></li>
                <li class="about-list"><i class="fas fa-building" id="me"></i> <span class="acc">Accommodation</span></li> 
                <li class="about-list dot">.</li>
                <li class="about-list"><i class="fas fa-universal-access"></i> Accessiblity</li>
                <li class="about-list dot">.</li>
                <li class="about-list"><i class="fas fa-wifi"></i> Wifi</li>
              </ul>
            </div>
    
            <div class="about-buttons flex">
              <button class="button">About Us</button>
              <a href="#" class="about-link flex">
                <span class="link-text">see more</span>
                <i class="fas fa-arrow-right about-arrowIcon"></i> 
              </a>
            </div>
          </div>
    
        </div>
      </section>


      <!-- contact section -->
      <section class="contacts" id="contact">
        <div class="content">
            <h2>Contact Us</h2>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sunt voluptate laboriosam in corporis ullam tempora at suscipit fugiat aspernatur veritatis aperiam harum unde facere consectetur sint soluta eligendi, error possimus.</p>
        </div>
        <div class="container">
            <div class="contactInfo">
                <div class="box">
                    <div class="icon"><i class="fa fa-address-card" aria-hidden="true"></i></div>
                    <div class="text">
                        <h3>Address</h3>
                        <p>4671 kataza road<br> Bugoolobi,kampala<br>5783908</p>
                    </div>
                </div>
                <div class="box">
                    <div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
                    <div class="text">
                        <h3>Phone</h3>
                        <p>+256-078-3457-098</p>
                    </div>
                </div>
                <div class="box">
                    <div class="icon"><i class="fa fa-envelope" aria-hidden="true"></i></div>
                    <div class="text">
                        <h3>Email</h3>
                        <p>hostelmanagementsystem@gmail.com</p>
                    </div>
                </div>
            </div>
            <div class="contactForm">
                <form action="contact.php" method="POST">
                    <h2>Send Message</h2>
                    <div class="inputBox">
                        <input type="text" name="fullName" required="required">
                        <span>Full name</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="email" required="required">
                        <span>Email</span>
                    </div>
                    <div class="inputBox">
                        <textarea  name="message" required="required"></textarea>
                        <span>Type your Message...</span>
                    </div>
                    <div class="inputBox">
                        <button type="submit">SEND</button>
                    </div>
                </form>
            </div>
        </div>
      
    </section>

    <!-- booking section -->
    <section class="booking-section" id="booking">
      <div class="container">
        <div class="booking-content">
          <div class="booking-form-container">
            <h3>Book Your Stay</h3>
        
            <form class="booking-form" id="bookingForm" action="display.php" method="POST">
              <input type="text" name="name" placeholder="Your Name" required>
              <input type="email" name="email" placeholder="Your Email" required>
              <input type="text" name="check_in" placeholder="Check-in Date" class="datepicker" required>
              <input type="text" name="check_out" placeholder="Check-out Date" class="datepicker" required>
              <select name="room_type" required>
                <option value="" disabled selected>Select Room Type</option>
                <option value="single">Single</option>
                <option value="double">Double</option>
                <option value="selfContained">Self Contained</option>
              </select>
              <button type="submit" class="button">Book Now</button>
            </form>
          </div>
          <div class="booking-image-container">
            <img src="images/UDS Design The GRIDS Hostel In Tokyo.jpeg" alt="">
          </div>
        </div>
      </div>
    </section>
    
     <!-- booking_details -->
         <section class="booking-details" id="bookingDetails">
            
            <h2> Booking Details </h2>
            <table>
                 <thead>
                     <tr>
                         <th> NAME</th>
                         <th>EMAIL </th>
                         <th>CHECK-IN DATE </th>
                         <th>CHECK-OUT DATE </th>
                         <th>ROOM TYPE </th>
                     </tr>
                 </thead>
                 <tbody>
                        <?php
                                 if($result->num_rows>0){
                                    while ($row = $result->fetch_assoc()){
                                        echo "<tr>";
                                        echo "<td>".$row['name']."</td>";
                                        echo "<td>".$row['email']."</td>";
                                        echo "<td>".$row['check_in']."</td>";
                                        echo "<td>".$row['check_out']."</td>";
                                        echo "<td>".$row['room_type']."</td>";
                                        echo "</tr>";
                                    }
                            
                                }else{
                                    echo"<tr><td colspan ='3'> No data found</td></tr>"; 
                                }
                                ?>
                             </tbody>

            </table>

      </section>
    <!-- footer -->
    <footer>
        <div class="row">
            <div class="col">
                <img src="images/Eo_circle_blue_white_letter-h(0).svg" alt="" class="logo">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt porro non, voluptatibus unde nam eius quod earum quasi dolor dolorem in fugit maxime quisquam consectetur consequuntur optio cum modi doloribus.</p>
            </div>
            <div class="col">
                <h3>Office</h3>
                <p>Kataza Road</p>
                <p>kataza close</p>
                <p>Kampala,Uganda</p>
                <p class="email-id">hostelmanagement@gmail.com</p>
                <h4>+256-764-798-171</h4>
            </div>
            <div class="col">
                <h3>Links</h3>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#about">About Us</a></li>
                    <li><a href="#contact">Contact</a></li>
                    <li><a href="#booking">booking</a></li>
                </ul>
            </div>
            <div class="col">
                <h3>Newsletter</h3>
                <form action="">
                    <i class="far fa-envelope"></i>
                    <input type="email" placeholder="Enter Your email id" required>
                    <button type="submit"><i class="fas fa-arrow-right"></i></button>
                </form>
                <div class="social-icons">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-whatsapp"></i>
                    <i class="fab fa-pinterest"></i>
                </div>
            </div>
        </div>

    </footer>
<section class="login">
    
</section>
<a href="#home" class="goback-arrow">
   <i class="fas fa-arrow-left"></i>
   <span>Go Back to Homepage</span>
</a>

    <script src="index.js"></script>
</body>
</html>