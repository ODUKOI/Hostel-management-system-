<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Hostel_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users_tbl WHERE email='$email' AND password='$password'";
$result = $conn->query($sql);

if ($result && $result->num_rows == 1) {
  // If there's exactly one matching user, set session and redirect to index.php
  $_SESSION['email'] = $email;
  header("Location: home.php");
  
  exit();
} else {
  // If no user or multiple users found, display error message
  echo "Invalid email or password.";
}
?>



