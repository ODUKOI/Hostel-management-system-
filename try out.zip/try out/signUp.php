<?php 

require_once'connect.php';

$signEmail = $_POST["signEmail"];
$signPassword = $_POST["signPassword"];

$insertQuery="insert into users_tbl(email, password)values('$signEmail','$signPassword')";

//function to insert data
//function called query() and we pass insertQuery
$insertData=$connect->query($insertQuery);
if ($insertData==true){
    echo"User registered";
}else{
    echo"User not registered";
}

?>