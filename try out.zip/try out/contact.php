<?php 

require_once'connect.php';

$fullName = $_POST["fullName"];
$email = $_POST["email"];
$message = $_POST["message"];

$insertQuery="insert into contact_tbl(full_name,email, message)values('$fullName','$email','$message')";

//function to insert data
//function called query() and we pass insertQuery
$insertData=$connect->query($insertQuery);
if ($insertData==true){
    echo'<div style="background-color:#d4edda; color:#155724; border: 1px solid #c3e6cb;padding:10px; margin-bottom:10px;">Message Submitted!!</div>';
}else{
    echo'<div style="background-color:#f8d7da; color:#721c24; border: 1px solid #f5c6cb;padding:10px; margin-bottom:10px;">Error:Unable to insert data.</div>';
}

?>