<?php 

require_once'connect.php';

$name = $_POST["name"];
$email = $_POST["email"];
$check_in = $_POST["check_in"];
$check_out = $_POST["check_out"];
$room_type = $_POST["room_type"];

$insertQuery="insert into booking_tbl(name, email, check_in, check_out, room_type)values('$name','$email','$check_in','$check_out','$room_type')";

//function to insert data
//function called query() and we pass insertQuery
$insertData=$connect->query($insertQuery);

if ($insertData==true){
    echo"User registered";
}else{
    echo"User not registered";
}

?>