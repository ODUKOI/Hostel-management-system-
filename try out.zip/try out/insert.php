<?php 

require_once'connect.php';
if($_SERVER["REQUEST_METHOD"] =="POST"){
$loginEmail = mysqli_real_escape_string($connect, $_POST["loginEmail"]);
$loginPassword = mysqli_real_escape_string($connect, $_POST["loginPassword"]);

$Query="Select * from users_tbl where email='$loginEmail'";


$bringData=$connect->query($Query);
if ($bringData->num_rows==1){
    $row =$bringData->fetch_assoc();
    $hashed_password =$row['password'];

    //verify password
    if (md5($loginPassword)===$hashed_password){
        $_SESSION['loginEmail']=$loginEmail;
        header("Location:index.php");
        exit();
    }else{
        echo"Invalid  username or password.";
    }
}else{
    echo"Invalid username or password.";
}}
?>
