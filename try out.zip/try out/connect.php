<?php
$serverName ="localhost";
$userName="root";
$password="";
$databaseName="Hostel_db";

$connect= new mysqli($serverName,$userName,$password,$databaseName);
// if ($connect==true) {
//   echo"Succefully connected to the database";
// }else{
//     echo"connection failed";
// }
?>
